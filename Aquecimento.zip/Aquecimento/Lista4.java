/*Lista1: classe para exercícios de aquecimento. */
import javax.swing.*;

public class Lista4
{
    public static void main(String args [])
    {
        /*Vetor de "entrada", que já é alocado e inicializado.
          Neste caso, o new é dispensado, pois o compualdor já
          dediz o número de posicções que devem ser alocadas. */

        int a[] = {32,45,89,66,12,35,10,96,38,15,13,11,65,81,35,64,16,89,54,19};

        /*  A variável n conterá sempre o tamanho do vetor a.
            Isto irá facilitar novos testes caso queira
            mudar o conteúdo do vetor a */
        
        int n = a.length;

        /*  Declaração e alocação do vetor b, em que será escrita a saída.
            Não sabemos quantos elementos serão necessários, mas sabemos
            que n serão suficientes. O objetivo dps exercícios é mudar o conteúdo do vetor b. 
            A variável m declarada a seguir também deve ser alterada, indicando quantos
            elementos de b são realmente importante para a resposta. */
        
        int b [] = new int [n];
        int m = 1;

        /*  A variável a seguire é usada como índice de laçoes. */
        int i;
        
        b[2] = a[0];
        
        for(i = 0; i < n; i++)
        {   
            b[1] = a[i];
            
            if(b[1] <= b[2])
            {  
               b[2] = a[i];             
               b[0] = i;
            }
        }

        String saida = "Resposta:\n";

        for (i = 0; i < m; i++)
            saida = saida + b[0] + " ";

        saida = saida + "\nFim.";

        JOptionPane.showMessageDialog(null, saida, "Lista4", JOptionPane.PLAIN_MESSAGE);
        System.exit (0);
    }
}